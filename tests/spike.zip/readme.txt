Spike plate archive fixture

The same 40 x 24 x 8 mm plate with a 12 mm bore and an 8 mm pin
as the mesh and Markdown fixtures. This archive is only for the
Quick Look listing, not for cadprobe.
