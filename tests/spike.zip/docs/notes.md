Through bore at the plate centre.
